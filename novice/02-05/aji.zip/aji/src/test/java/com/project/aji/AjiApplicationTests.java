package com.project.aji;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AjiApplicationTests {

	@Test
	void contextLoads() {
	}

}
